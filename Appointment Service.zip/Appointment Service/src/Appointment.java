
public class Appointment {
	@Test
	void testApptConstructor() {
		Calendar c = Calendar.getInstance();
		c.set(2022, 10, 5, 9, 15);
		Date date = c.getTime();
		
		
		
		System.out.println("Date set to " + date);
		
		
		
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("12345678901", date, "Appt Description");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment(null, date , "Appt Description");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", date , "Thisisadescription"
					+ "thatiswaytoolongtobevalidforthisconstructor");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", date , null);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", null , "Appt Description");
		});
		
		
		date.setTime(0);
		System.out.println("Date set to " + date);
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", date , "Appt Description");
		});
		
		
		Date newDate = c.getTime();
		Appointment appt = new Appointment("1234567890", newDate, "Appt Description");
		assertTrue(appt.GetID().equals("1234567890"));
		assertTrue(appt.GetApptDate().equals(newDate));
		assertTrue(appt.GetDescription().equals("Appt Description"));
		
	}
	
	@Test
	void testSetters() {
		Calendar c = Calendar.getInstance();
		c.set(2022, 10, 5, 9, 15);
		Date date = c.getTime();
		Date newDate = c.getTime();
		Date badDate = new Date();
		badDate.setTime(10000);
		
		
		Appointment appt = new Appointment("1234567890", date, "Appt Description");
		
		
		appt.SetApptDescription("This is a description");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetApptDescription(null);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetApptDescription("Thisdescriptionistoolongtobevalidandwillthrowanerror");
		});
		
		assertTrue(appt.GetDescription().equals("This is a description"));
		
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetApptDate(badDate);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetApptDate(null);
		});
		
	
		appt.SetApptDate(newDate);
		
		assertTrue(appt.GetApptDate().equals(newDate));
		
	}
}
