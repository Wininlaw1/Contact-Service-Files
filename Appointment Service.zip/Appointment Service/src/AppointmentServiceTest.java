
public class AppointmentServiceTest {
	Date createADate() {
		Calendar c = Calendar.getInstance();
		c.set(2022, 10, 5, 9, 15);
		Date date = c.getTime();
		return date;
	}
	
	Date createBadDate() {
		Date date = new Date();
		date.setTime(1000000);
		return date;
	}
	
	
	@Test
	void testConstructor() {
		var apptService = new AppointmentService();
		assertTrue(apptService.GetAppointmentList().isEmpty());
		assertEquals(apptService.GetAppointmentCount(), 0);
		
		apptService.AddAppointment(createADate(), "Description");		
		apptService.PrintAppointmentList();
	}
	
	@Test
	void testAddAppointmentMethodNullDate() {
		var apptService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.AddAppointment(null, "Description");
		});
	}
	@Test
	void testAddAppointmentMethodNullDescription() {
		var apptService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.AddAppointment(createADate(), null);
		});
	}
	@Test
	void testAddAppointmentMethodBadDate() {
		var apptService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.AddAppointment(createBadDate(), "Description");
		});
	}
	@Test
	void testAddAppointmentMethodBadDescription() {
		var apptService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.AddAppointment(createADate(), "thisisadescriptionthat"
					+ "iswaaytoolongtobevalidintheprogram");
		});
	}
	
	@Test
	void testAddAppointmentMethodWithValidParameters() {
		var apptService = new AppointmentService();
		
		apptService.AddAppointment(createADate(), "This is a good description");
		assertEquals(apptService.GetAppointmentCount(), 1);
		assertTrue(!apptService.GetAppointmentList().isEmpty());
		apptService.PrintAppointmentList();
		
		
	}
	
	
	@Test
	void testRemoveMethodListEmpty() {
		var apptService = new AppointmentService();
	
		apptService.RemoveAppointment("1234567");
	}
	
	@Test
	void testRemoveMethodIDNull() {
		var apptService = new AppointmentService();
		apptService.AddAppointment(createADate(), "TO REMOVE");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.RemoveAppointment(null);
		});
	}
	@Test 
	void testRemoveMethodIDTooLong() {
		var apptService = new AppointmentService();
		apptService.AddAppointment(createADate(), "TO REMOVE");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.RemoveAppointment("1234567800090123");
					
		});
	}
	
	@Test
	void testRemoveMethodAppointmentNotInList() {
		var apptService = new AppointmentService();
		apptService.AddAppointment(createADate(), "TO REMOVE");
		apptService.RemoveAppointment("1234567");
		
		assertTrue(!apptService.GetAppointmentList().isEmpty());
	}
	
	@Test
	void testRemoveMethodAppointmentIsInList() {
		var apptService = new AppointmentService();
		apptService.AddAppointment(createADate(), "TO REMOVE");
		Appointment appt = apptService.GetAppointmentList().elementAt(0);
		apptService.RemoveAppointment(appt.GetID());
		assertTrue(apptService.GetAppointmentList().isEmpty());
	}
}
