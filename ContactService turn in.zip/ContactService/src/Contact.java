
public class Contact {

}
